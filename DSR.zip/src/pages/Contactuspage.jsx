import React from 'react'
import Footer from '../components/shared/Footer'
import Contactuswrapper from '../components/contsctus/Contactuswrapper'
import Headertwo from '../components/shared/Headertwo'

function Contactuspage() {
    return (
        <div className="body-wrapper">
            <Headertwo/>
            <Contactuswrapper />
            <Footer />
        </div>
    )
}

export default Contactuspage