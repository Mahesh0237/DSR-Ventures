import React from 'react'
import Headertwo from '../components/shared/Headertwo'
import Footer from '../components/shared/Footer'
import Projectswrapper from '../components/projects/Projectswrapper'
function Projectpage() {
    return (
        <div className="body-wrapper">
            <Headertwo />
            <Projectswrapper/>
            <Footer />
        </div>
    )
}

export default Projectpage