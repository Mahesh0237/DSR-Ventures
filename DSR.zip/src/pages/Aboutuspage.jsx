import React from 'react'
import Headertwo from '../components/shared/Headertwo'
import Footer from '../components/shared/Footer'
import Aboutuswrapper from '../components/aboutus/Aboutuswrapper'

function Aboutuspage() {
    return (
        <div className="body-wrapper">
            <Headertwo />
            <Aboutuswrapper />
            <Footer />
        </div>
    )
}

export default Aboutuspage