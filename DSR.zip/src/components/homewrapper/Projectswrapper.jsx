import { Container, Grid, Group, Stack, Text } from '@mantine/core'
import React, { useRef } from 'react'
import Projectshared from './shared/Projectshared'
import project1 from '../../assets/project11.jpeg'
import project2 from '../../assets/project22.jpeg'
import project3 from '../../assets/project33.jpeg'
import project4 from '../../assets/home1.avif'
import farm4 from '../../assets/home2.avif'
import home3 from '../../assets/home3.avif'
import home4 from '../../assets/home4.avif'
import home5 from '../../assets/home5.avif'
import explore from '../../assets/explore.jpg'
import Enquireyform from './shared/Enquireyform'
import { Carousel } from '@mantine/carousel'
import Autoplay from 'embla-carousel-autoplay';

function Projectswrapper() {
    const autoplay = useRef(Autoplay({ delay: 2000 }));
    return (
        <main className="dsr-home-page">
            <section className="latest-listings">
                <div className="section-wrapper">
                    <div className="latest-listings-wrapper">
                        <div className="section-heading">
                            <h2>Projects</h2>
                        </div>
                        <div className="latest-listings-slider">
                            <Group justify="center">
                                <div className="slide">
                                    <a className="main-part" href='/projectdetails'>
                                        <div className="img">
                                            <div className="box">
                                                <div></div>
                                            </div>
                                            <img src={project1} />
                                        </div>
                                        <h3>PRERANA GREENS</h3>
                                        <div className="heading">
                                            <p>We have a just added a lot more space into your life.Here's PRERANA INNOVATION DEVELOPERS.</p>
                                        </div>
                                        <div className="link">
                                            View More
                                        </div>
                                    </a>
                                </div>
                                <div className="slide">
                                    <a className="main-part" href='/projectdetails'>
                                        <div className="img">
                                            <div className="box">
                                                <div></div>
                                            </div>
                                            <img src={project2} />
                                        </div>
                                        <h3>GREENWOOD MEADOWS</h3>
                                        <div className="heading">
                                            <p>D.C.Converted residential sites in fully developed plotted layout in Maragondanahalli,  </p>
                                        </div>
                                        <div className="link">View More</div>
                                    </a>
                                </div>
                                <div className="slide">
                                    <a className="main-part" href='/projectdetails'>
                                        <div className="img">
                                            <div className="box">
                                                <div></div>
                                            </div>
                                            <img src={project3} />
                                        </div>
                                        <h3>Green Avenues</h3>
                                        <div className="heading">
                                            <p>Green Avenues residential sites in fully developed plotted layout in Ramsandra village Narsapura.</p>
                                        </div>
                                        <div className="link">View More</div>
                                    </a>
                                </div>
                            </Group>
                        </div>
                    </div>
                </div>
            </section>

            <section className="testimonials">
                <div className="section-wrapper">
                    <div className="testimonial-slider-wrapper">
                        <div className="testimonial-slide-inner">
                            {/* <div className="grey-box" ></div> */}
                            <div className="image-part" >
                                <img src={project4} alt='img' />
                            </div>
                            <div className="content-part">
                                <h2 className="heading-h2">
                                    <p>Driven by Design</p>
                                </h2>
                                <div className="heading-p-wrapper mobile-hide">
                                    <p>Passionate about Design - Meticulous Craftsmanship, Aesthetics, and Functionality Unite in Every Creation. Architectural Brilliance Personified.</p>
                                </div>
                                <div className="heading-p-wrapper desktop-hide">
                                    <p>Passionate about Design - Meticulous Craftsmanship, Aesthetics, and Functionality Unite in Every Creation. Architectural Brilliance Personified.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section className='aboutus mb-5'>
                <Grid px={50}>
                    <Grid.Col span={{ base: 12, md: 6, lg: 6 }}>
                        <Stack p={15}>
                            <Text style={{ fontSize: "35px" }} fw={700}>Explore the Grandeur of Design Driven Projects</Text>
                            <Text size='lg'> Detail crafted with love to harmonise with your soul. surrounding to create a mesmerising living experience</Text>
                            <Text size='lg'>Classical Elegance in every inch bringing timeless charm and sophistication to your home</Text>
                            <Text size='lg'>An epitome of contemporary living, modern designs that are driven by captivating æsthetics and keen attention to detail</Text>
                        </Stack>
                    </Grid.Col>
                    <Grid.Col span={{ base: 12, md: 6, lg: 6 }}>
                        <Carousel
                            withIndicators
                            height={350}
                            loop
                            withControls={false}
                            plugins={[autoplay.current]}
                            onMouseEnter={autoplay.current.stop}
                            onMouseLeave={autoplay.current.reset}
                        >
                            <Carousel.Slide>
                                <img src={explore} height="100%" width="100%" alt='' />
                            </Carousel.Slide>
                            <Carousel.Slide>
                                <img src={home3} height="100%" width="100%" alt='' />
                            </Carousel.Slide>
                            <Carousel.Slide>
                                <img src={home4} height="100%" width="100%" alt='' />
                            </Carousel.Slide>
                            <Carousel.Slide>
                                <img src={home5} height="100%" width="100%" alt='' />
                            </Carousel.Slide>
                        </Carousel>
                    </Grid.Col>
                </Grid> 
            </section>

            <section className='aboutus my-5'>
                <Grid px={50} mt={100}>
                    <Grid.Col span={{ base: 12, md: 6, lg: 6 }}>
                        <Carousel
                            withIndicators
                            height={350}
                            loop
                            withControls={false}
                            plugins={[autoplay.current]}
                            onMouseEnter={autoplay.current.stop}
                            onMouseLeave={autoplay.current.reset}
                        >
                            <Carousel.Slide>
                                <img src={farm4} height="100%" width="100%" alt='' />
                            </Carousel.Slide>
                            <Carousel.Slide>
                                <img src={home3} height="100%" width="100%" alt='' />
                            </Carousel.Slide>
                            <Carousel.Slide>
                                <img src={home4} height="100%" width="100%" alt='' />
                            </Carousel.Slide>
                            <Carousel.Slide>
                                <img src={home5} height="100%" width="100%" alt='' />
                            </Carousel.Slide>
                        </Carousel>
                    </Grid.Col>
                    <Grid.Col span={{ base: 12, md: 6, lg: 6 }}>
                        <Stack px={25}>
                            <Text style={{ fontSize: "30px" }} ta="center" fw={700}>About Us</Text>
                            <Text size='lg'>
                                DSR VENTURES was established in 2011, with Land Development and apartment construction as its main focus, we strive to build superior apartments for our customers with the highest level of quality construction services at fair and market competitive prices.

                                We research, analyze, and determine the best cost-effective and regulatory design to suit our customer needs.</Text>

                        </Stack>
                    </Grid.Col>
                </Grid>
            </section>
            <Enquireyform />
            <div className="enquiry-sticky">
                <a href='/projectsdetail'><div className="enquiry">Enquire Now</div></a>
            </div>
        </main>
    )
}

export default Projectswrapper